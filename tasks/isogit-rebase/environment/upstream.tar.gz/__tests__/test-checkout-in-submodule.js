import * as path from 'path'

import {
  Errors,
  checkout,
  currentBranch,
  listFiles,
  add,
  commit,
  branch,
  getConfig,
  fetch as gitFetch,
  remove,
  setConfig,
  statusMatrix,
  hashBlob,
  updateIndex,
  annotatedTag,
  resolveRef,
  readCommit,
  writeTag,
  writeRef,
} from 'isomorphic-git'
import http from 'isomorphic-git/http'

/* eslint-env node, browser, jasmine */

/* eslint-env node, browser, jasmine */

import { makeFixtureAsSubmodule } from './__helpers__/FixtureFSSubmodule.js'

// this is so it works with either Node local tests or Browser WAN tests
const localhost =
  typeof window === 'undefined' ? '127.0.0.1' : window.location.hostname

describe('checkout', () => {
  it('checkout', async () => {
    // Setup
    const { fs, dir, gitdir, gitdirsmfullpath } =
      await makeFixtureAsSubmodule('test-checkout')
    const onPostCheckout = []
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      onPostCheckout: args => {
        onPostCheckout.push(args)
      },
    })
    let files = await fs.readdir(dir)
    files = files.filter(e => e !== '.git')
    expect(files.sort()).toMatchInlineSnapshot(`
      [
        ".babelrc",
        ".editorconfig",
        ".flowconfig",
        ".gitignore",
        "LICENSE.md",
        "README.md",
        "package.json",
        "shrinkwrap.yaml",
        "src",
        "test",
      ]
    `)
    const index = await listFiles({ fs, dir, gitdir })
    expect(index).toMatchInlineSnapshot(`
      [
        ".babelrc",
        ".editorconfig",
        ".flowconfig",
        ".gitignore",
        "LICENSE.md",
        "README.md",
        "package.json",
        "shrinkwrap.yaml",
        "src/commands/checkout.js",
        "src/commands/config.js",
        "src/commands/fetch.js",
        "src/commands/init.js",
        "src/index.js",
        "src/models/GitBlob.js",
        "src/models/GitCommit.js",
        "src/models/GitConfig.js",
        "src/models/GitTree.js",
        "src/utils/combinePayloadAndSignature.js",
        "src/utils/commitSha.js",
        "src/utils/exists.js",
        "src/utils/mkdirs.js",
        "src/utils/read.js",
        "src/utils/resolveRef.js",
        "src/utils/unwrapObject.js",
        "src/utils/wrapCommit.js",
        "src/utils/write.js",
        "test/resolveRef.js",
        "test/smoke.js",
        "test/snapshots/resolveRef.js.md",
        "test/snapshots/resolveRef.js.snap",
      ]
    `)
    const sha = await fs.read(gitdirsmfullpath + '/HEAD', 'utf8')
    expect(sha).toBe('ref: refs/heads/test-branch\n')
    expect(onPostCheckout).toEqual([
      {
        newHead: 'e10ebb90d03eaacca84de1af0a59b444232da99e',
        previousHead: '0f55956cbd50de80c2f86e6e565f00c92ce86631',
        type: 'branch',
      },
    ])
  })

  it('checkout by tag', async () => {
    // Setup
    const { fs, dir, gitdir, gitdirsmfullpath } =
      await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'v1.0.0',
    })
    let files = await fs.readdir(dir)
    files = files.filter(e => e !== '.git')
    expect(files.sort()).toMatchInlineSnapshot(`
      [
        ".babelrc",
        ".editorconfig",
        ".flowconfig",
        ".gitignore",
        "LICENSE.md",
        "README.md",
        "package.json",
        "shrinkwrap.yaml",
        "src",
        "test",
      ]
    `)
    const index = await listFiles({ fs, dir, gitdir })
    expect(index).toMatchInlineSnapshot(`
      [
        ".babelrc",
        ".editorconfig",
        ".flowconfig",
        ".gitignore",
        "LICENSE.md",
        "README.md",
        "package.json",
        "shrinkwrap.yaml",
        "src/commands/checkout.js",
        "src/commands/config.js",
        "src/commands/fetch.js",
        "src/commands/init.js",
        "src/index.js",
        "src/models/GitBlob.js",
        "src/models/GitCommit.js",
        "src/models/GitConfig.js",
        "src/models/GitTree.js",
        "src/utils/combinePayloadAndSignature.js",
        "src/utils/commitSha.js",
        "src/utils/exists.js",
        "src/utils/mkdirs.js",
        "src/utils/read.js",
        "src/utils/resolveRef.js",
        "src/utils/unwrapObject.js",
        "src/utils/wrapCommit.js",
        "src/utils/write.js",
        "test/resolveRef.js",
        "test/smoke.js",
        "test/snapshots/resolveRef.js.md",
        "test/snapshots/resolveRef.js.snap",
      ]
    `)
    const sha = await fs.read(gitdirsmfullpath + '/HEAD', 'utf8')
    expect(sha).toBe('e10ebb90d03eaacca84de1af0a59b444232da99e\n')
  })

  it('checkout by annotated tag', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await annotatedTag({
      fs,
      gitdir,
      ref: 'v1.0.0-annotated',
      object: 'v1.0.0',
      message: 'annotated tag',
      tagger: {
        name: 'Mr. Test',
        email: 'mrtest@example.com',
        timestamp: 1262356920,
        timezoneOffset: -0,
      },
    })
    const commitOid = await resolveRef({ fs, gitdir, ref: 'v1.0.0' })
    // Test
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'v1.0.0-annotated',
    })
    // HEAD should point to the commit, not to the tag object
    expect(await resolveRef({ fs, gitdir, ref: 'HEAD' })).toBe(commitOid)
  })

  it('checkout by annotated tag oid', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await annotatedTag({
      fs,
      gitdir,
      ref: 'v1.0.0-annotated',
      object: 'v1.0.0',
      message: 'annotated tag',
      tagger: {
        name: 'Mr. Test',
        email: 'mrtest@example.com',
        timestamp: 1262356920,
        timezoneOffset: -0,
      },
    })
    const commitOid = await resolveRef({ fs, gitdir, ref: 'v1.0.0' })
    const tagOid = await resolveRef({ fs, gitdir, ref: 'v1.0.0-annotated' })
    // Test
    await checkout({
      fs,
      dir,
      gitdir,
      ref: tagOid,
    })
    // HEAD should point to the commit, not to the tag object
    expect(await resolveRef({ fs, gitdir, ref: 'HEAD' })).toBe(commitOid)
  })

  it('checkout filepaths from an annotated tag of a tree', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    const { commit: c } = await readCommit({
      fs,
      gitdir,
      oid: await resolveRef({ fs, gitdir, ref: 'v1.0.0' }),
    })
    await annotatedTag({
      fs,
      gitdir,
      ref: 'tree-tag',
      object: c.tree,
      message: 'annotated tag of a tree',
      tagger: {
        name: 'Mr. Test',
        email: 'mrtest@example.com',
        timestamp: 1262356920,
        timezoneOffset: -0,
      },
    })
    await fs.write(`${dir}/README.md`, 'changed', 'utf8')
    // Test
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'tree-tag',
      filepaths: ['README.md'],
      noUpdateHead: true,
      force: true,
    })
    expect(await fs.read(`${dir}/README.md`, 'utf8')).not.toBe('changed')
  })

  it('checkout by SHA', async () => {
    // Setup
    const { fs, dir, gitdir, gitdirsmfullpath } =
      await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'e10ebb90d03eaacca84de1af0a59b444232da99e',
    })
    let files = await fs.readdir(dir)
    files = files.filter(e => e !== '.git')
    expect(files.sort()).toMatchInlineSnapshot(`
      [
        ".babelrc",
        ".editorconfig",
        ".flowconfig",
        ".gitignore",
        "LICENSE.md",
        "README.md",
        "package.json",
        "shrinkwrap.yaml",
        "src",
        "test",
      ]
    `)
    const index = await listFiles({ fs, dir, gitdir })
    expect(index).toMatchInlineSnapshot(`
      [
        ".babelrc",
        ".editorconfig",
        ".flowconfig",
        ".gitignore",
        "LICENSE.md",
        "README.md",
        "package.json",
        "shrinkwrap.yaml",
        "src/commands/checkout.js",
        "src/commands/config.js",
        "src/commands/fetch.js",
        "src/commands/init.js",
        "src/index.js",
        "src/models/GitBlob.js",
        "src/models/GitCommit.js",
        "src/models/GitConfig.js",
        "src/models/GitTree.js",
        "src/utils/combinePayloadAndSignature.js",
        "src/utils/commitSha.js",
        "src/utils/exists.js",
        "src/utils/mkdirs.js",
        "src/utils/read.js",
        "src/utils/resolveRef.js",
        "src/utils/unwrapObject.js",
        "src/utils/wrapCommit.js",
        "src/utils/write.js",
        "test/resolveRef.js",
        "test/smoke.js",
        "test/snapshots/resolveRef.js.md",
        "test/snapshots/resolveRef.js.snap",
      ]
    `)
    const sha = await fs.read(gitdirsmfullpath + '/HEAD', 'utf8')
    expect(sha).toBe('e10ebb90d03eaacca84de1af0a59b444232da99e\n')
  })

  it('checkout unfetched branch', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    let error = null
    try {
      await checkout({ fs, dir, gitdir, ref: 'missing-branch' })
      throw new Error('Checkout should have failed.')
    } catch (err) {
      error = err
    }
    expect(error).not.toBeNull()
    expect(error.caller).toEqual('git.checkout')
    error = error.toJSON()
    delete error.stack
    expect(error).toMatchInlineSnapshot(`
      {
        "caller": "git.checkout",
        "code": "CommitNotFetchedError",
        "data": {
          "oid": "033417ae18b174f078f2f44232cb7a374f4c60ce",
          "ref": "missing-branch",
        },
        "message": "Failed to checkout "missing-branch" because commit 033417ae18b174f078f2f44232cb7a374f4c60ce is not available locally. Do a git fetch to make the branch available locally.",
      }
    `)
  })

  it('checkout annotated tag of an unfetched commit', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    const missingOid = '1111111111111111111111111111111111111111'
    const tagOid = await writeTag({
      fs,
      gitdir,
      tag: {
        object: missingOid,
        type: 'commit',
        tag: 'missing-tag',
        tagger: {
          name: 'Mr. Test',
          email: 'mrtest@example.com',
          timestamp: 1262356920,
          timezoneOffset: -0,
        },
        message: 'annotated tag of a missing commit',
      },
    })
    await writeRef({ fs, gitdir, ref: 'refs/tags/missing-tag', value: tagOid })
    let error = null
    // Test
    try {
      await checkout({ fs, dir, gitdir, ref: 'missing-tag' })
    } catch (err) {
      error = err
    }
    expect(error instanceof Errors.CommitNotFetchedError).toBe(true)
    expect(error.data.oid).toBe(missingOid)
  })

  it('checkout file permissions', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await branch({ fs, dir, gitdir, ref: 'other', checkout: true })
    await checkout({ fs, dir, gitdir, ref: 'test-branch' })
    await fs.write(dir + '/regular-file.txt', 'regular file', {
      mode: 0o666,
    })
    await fs.write(dir + '/executable-file.sh', 'executable file', {
      mode: 0o777,
    })
    const expectedRegularFileMode = (await fs.lstat(dir + '/regular-file.txt'))
      .mode
    const expectedExecutableFileMode = (
      await fs.lstat(dir + '/executable-file.sh')
    ).mode
    await add({ fs, dir, gitdir, filepath: 'regular-file.txt' })
    await add({ fs, dir, gitdir, filepath: 'executable-file.sh' })
    await commit({
      fs,
      dir,
      gitdir,
      author: { name: 'Git', email: 'git@example.org' },
      message: 'add files',
    })
    await checkout({ fs, dir, gitdir, ref: 'other' })
    await checkout({ fs, dir, gitdir, ref: 'test-branch' })
    const actualRegularFileMode = (await fs.lstat(dir + '/regular-file.txt'))
      .mode
    const actualExecutableFileMode = (
      await fs.lstat(dir + '/executable-file.sh')
    ).mode
    expect(actualRegularFileMode).toEqual(expectedRegularFileMode)
    expect(actualExecutableFileMode).toEqual(expectedExecutableFileMode)
  })

  it('checkout changing file permissions', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')

    await fs.write(dir + '/regular-file.txt', 'regular file', {
      mode: 0o666,
    })
    await fs.write(dir + '/executable-file.sh', 'executable file', {
      mode: 0o777,
    })
    const { mode: expectedRegularFileMode } = await fs.lstat(
      dir + '/regular-file.txt'
    )
    const { mode: expectedExecutableFileMode } = await fs.lstat(
      dir + '/executable-file.sh'
    )

    // Test
    await checkout({ fs, dir, gitdir, ref: 'regular-file' })
    const { mode: actualRegularFileMode } = await fs.lstat(dir + '/hello.sh')
    expect(actualRegularFileMode).toEqual(expectedRegularFileMode)

    await checkout({ fs, dir, gitdir, ref: 'executable-file' })
    const { mode: actualExecutableFileMode } = await fs.lstat(dir + '/hello.sh')
    expect(actualExecutableFileMode).toEqual(expectedExecutableFileMode)
  })

  it('checkout directories using filepaths', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      filepaths: ['src/models', 'test'],
    })
    let files = await fs.readdir(dir)
    files = files.filter(e => e !== '.git')
    expect(files.sort()).toMatchInlineSnapshot(`
      [
        "src",
        "test",
      ]
    `)
    const index = await listFiles({ fs, dir, gitdir })
    expect(index).toMatchInlineSnapshot(`
      [
        "src/models/GitBlob.js",
        "src/models/GitCommit.js",
        "src/models/GitConfig.js",
        "src/models/GitTree.js",
        "test/resolveRef.js",
        "test/smoke.js",
        "test/snapshots/resolveRef.js.md",
        "test/snapshots/resolveRef.js.snap",
      ]
    `)
  })

  it('checkout files using filepaths', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      filepaths: ['src/models/GitBlob.js', 'src/utils/write.js'],
    })
    let files = await fs.readdir(dir)
    files = files.filter(e => e !== '.git')
    expect(files.sort()).toMatchInlineSnapshot(`
      [
        "src",
      ]
    `)
    const index = await listFiles({ fs, dir, gitdir })
    expect(index).toMatchInlineSnapshot(`
      [
        "src/models/GitBlob.js",
        "src/utils/write.js",
      ]
    `)
  })

  it('checkout detects conflicts', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await fs.write(`${dir}/README.md`, 'Hello world', 'utf8')
    // Test
    let error = null
    try {
      await checkout({
        fs,
        dir,
        gitdir,
        ref: 'test-branch',
      })
    } catch (e) {
      error = e
    }
    expect(error).not.toBeNull()
    expect(error instanceof Errors.CheckoutConflictError).toBe(true)
    expect(error.data.filepaths).toEqual(['README.md'])
  })

  it('checkout files ignoring conflicts dry run', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await fs.write(`${dir}/README.md`, 'Hello world', 'utf8')
    // Test
    let error = null
    try {
      await checkout({
        fs,
        dir,
        gitdir,
        ref: 'test-branch',
        force: true,
        dryRun: true,
      })
    } catch (e) {
      error = e
    }
    expect(error).toBeNull()
    expect(await fs.read(`${dir}/README.md`, 'utf8')).toBe('Hello world')
  })

  it('checkout files ignoring conflicts', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await fs.write(`${dir}/README.md`, 'Hello world', 'utf8')
    // Test
    let error = null
    try {
      await checkout({
        fs,
        dir,
        gitdir,
        ref: 'test-branch',
        force: true,
      })
    } catch (e) {
      error = e
    }
    expect(error).toBeNull()
    expect(await fs.read(`${dir}/README.md`, 'utf8')).not.toBe('Hello world')
  })

  it('restore files to HEAD state by not providing a ref', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
    })
    await fs.write(`${dir}/README.md`, 'Hello world', 'utf8')
    // Test
    let error = null
    try {
      await checkout({
        fs,
        dir,
        gitdir,
        force: true,
      })
    } catch (e) {
      error = e
    }
    expect(error).toBeNull()
    expect(await fs.read(`${dir}/README.md`, 'utf8')).not.toBe('Hello world')
  })

  it('restores filepaths from the index when no ref is provided', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await checkout({ fs, dir, gitdir, ref: 'test-branch' })
    await fs.write(`${dir}/README.md`, 'staged content', 'utf8')
    await add({ fs, dir, gitdir, filepath: 'README.md' })
    await fs.write(`${dir}/README.md`, 'workdir content', 'utf8')

    await checkout({
      fs,
      dir,
      gitdir,
      force: true,
      filepaths: ['README.md'],
    })

    expect(await fs.read(`${dir}/README.md`, 'utf8')).toBe('staged content')
    expect(
      await statusMatrix({ fs, dir, gitdir, filepaths: ['README.md'] })
    ).toEqual([['README.md', 1, 2, 2]])
  })

  it('does not delete a staged-deleted filepath when restoring from the index', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    const filepath = 'src/utils/exists.js'
    await checkout({ fs, dir, gitdir, ref: 'test-branch' })
    const contents = await fs.read(`${dir}/${filepath}`)
    await remove({ fs, dir, gitdir, filepath })

    await checkout({ fs, dir, gitdir, force: true, filepaths: [filepath] })

    expect(await fs.read(`${dir}/${filepath}`)).toEqual(contents)
    expect(await listFiles({ fs, dir, gitdir })).not.toContain(filepath)
  })

  it('checkout files should not delete other files', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
    })
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      filepaths: ['src/utils', 'test'],
    })
    let files = await fs.readdir(dir)
    files = files.filter(e => e !== '.git')
    expect(files).toContain('README.md')
  })

  it('should setup the remote tracking branch by default', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-fetch-cors')

    await setConfig({
      fs,
      gitdir,
      path: 'http.corsProxy',
      value: `http://${localhost}:9999`,
    })

    // fetch `test-branch` so `refs/remotes/test-branch` exists but `refs/heads/test-branch` does not
    await gitFetch({
      fs,
      dir,
      gitdir,
      http,
      singleBranch: true,
      remote: 'origin',
      ref: 'test-branch',
    })

    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
    })

    const [merge, remote] = await Promise.all([
      getConfig({
        fs,
        dir,
        gitdir,
        path: 'branch.test-branch.merge',
      }),
      getConfig({
        fs,
        dir,
        gitdir,
        path: 'branch.test-branch.remote',
      }),
    ])

    expect(merge).toContain('refs/heads/test-branch')
    expect(remote).toContain('origin')
  })

  it('should setup the remote tracking branch with `track: true`', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-fetch-cors')

    await setConfig({
      fs,
      gitdir,
      path: 'http.corsProxy',
      value: `http://${localhost}:9999`,
    })

    // fetch `test-branch` so `refs/remotes/test-branch` exists but `refs/heads/test-branch` does not
    await gitFetch({
      fs,
      dir,
      gitdir,
      http,
      singleBranch: true,
      remote: 'origin',
      ref: 'test-branch',
    })

    // checking the test-branch with `track: true` should setup the remote tracking branch
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      track: true,
    })

    const [merge, remote] = await Promise.all([
      getConfig({
        fs,
        dir,
        gitdir,
        path: 'branch.test-branch.merge',
      }),
      getConfig({
        fs,
        dir,
        gitdir,
        path: 'branch.test-branch.remote',
      }),
    ])

    expect(merge).toContain('refs/heads/test-branch')
    expect(remote).toContain('origin')
  })

  it('should not setup the remote tracking branch with `track: false`', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-fetch-cors')

    await setConfig({
      fs,
      gitdir,
      path: 'http.corsProxy',
      value: `http://${localhost}:9999`,
    })

    // fetch `test-branch` so `refs/remotes/test-branch` exists but `refs/heads/test-branch` does not
    await gitFetch({
      fs,
      dir,
      gitdir,
      http,
      singleBranch: true,
      remote: 'origin',
      ref: 'test-branch',
    })

    // checking the test-branch with `track: false` should not setup the remote tracking branch
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      track: false,
    })

    const [merge, remote] = await Promise.all([
      getConfig({
        fs,
        dir,
        gitdir,
        path: 'branch.test-branch.merge',
      }),
      getConfig({
        fs,
        dir,
        gitdir,
        path: 'branch.main.remote',
      }),
    ])

    expect(merge).toBeUndefined()
    expect(remote).toBeUndefined()
  })

  it('onPostCheckout dry run', async () => {
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    const onPostCheckout = []
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      dryRun: true,
      onPostCheckout: args => {
        onPostCheckout.push(args)
      },
    })

    expect(onPostCheckout).toEqual([
      {
        newHead: 'e10ebb90d03eaacca84de1af0a59b444232da99e',
        previousHead: '0f55956cbd50de80c2f86e6e565f00c92ce86631',
        type: 'branch',
      },
    ])
  })

  it('onPostCheckout with specified filepaths', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
    })
    // Test
    const onPostCheckout = []
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
      filepaths: ['src/utils', 'test'],
      onPostCheckout: args => {
        onPostCheckout.push(args)
      },
    })

    expect(onPostCheckout).toEqual([
      {
        newHead: 'e10ebb90d03eaacca84de1af0a59b444232da99e',
        previousHead: 'e10ebb90d03eaacca84de1af0a59b444232da99e',
        type: 'file',
      },
    ])
  })

  it('checkout should not delete ignored files', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-checkout')

    // Checkout the test-branch
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
    })

    // Create a branch from test-branch
    await branch({
      fs,
      dir,
      gitdir,
      ref: 'branch-w-ignored-dir',
      checkout: true,
    })
    // Add a regular file to the ignored dir
    await fs.write(`${dir}/ignored/regular-file.txt`, 'regular file', {
      mode: 0o666,
    })

    // Add and commit a gitignore, ignoring everything but itself
    const gitignoreContent = `*
!.gitignore`
    await fs.write(`${dir}/ignored/.gitignore`, gitignoreContent, {
      mode: 0o666,
    })
    await add({ fs, dir, gitdir, filepath: 'ignored/.gitignore' })

    await commit({
      fs,
      dir,
      gitdir,
      author: { name: 'Git', email: 'git@example.org' },
      message: 'add gitignore',
    })

    // Checkout the test-branch, which does not contain the ignore/.gitignore
    // should not delete files from ignore, but leave them as untracked in the working tree
    await checkout({
      fs,
      dir,
      gitdir,
      ref: 'test-branch',
    })
    const files = await fs.readdir(`${dir}/ignored`)
    expect(files).toContain('regular-file.txt')
    expect(files).not.toContain('.gitignore')
  })

  it('checkout a branch named after a git system file keeps HEAD attached', async () => {
    // Setup
    const { fs, dir, gitdir, gitdirsmfullpath } =
      await makeFixtureAsSubmodule('test-checkout')
    await branch({ fs, dir, gitdir, ref: 'index', checkout: false })
    // Test
    await checkout({ fs, dir, gitdir, ref: 'index' })
    // Every repository has a `.git/index`, and checkout asks GitRefManager to
    // expand the ref before deciding whether it is a branch. When the expansion
    // returns the index file instead of refs/heads/index, checkout concludes it
    // is not a branch and detaches HEAD, so later commits belong to no branch.
    expect(await currentBranch({ fs, dir, gitdir })).toEqual('index')
    expect(await fs.read(path.join(gitdirsmfullpath, 'HEAD'), 'utf8')).toEqual(
      'ref: refs/heads/index\n'
    )
  })

  it('writes .git/index once when refreshing the stat info of many files', async () => {
    // Setup
    const { fs, dir, gitdir, gitdirsmfullpath } =
      await makeFixtureAsSubmodule('test-checkout')
    await checkout({ fs, dir, gitdir, ref: 'test-branch' })
    // Blank the stat info of some unmodified files in the index, so the
    // stat-cache refresh fires for each of them while checkout analyzes the
    // working tree. Anything that touches tracked files without changing
    // them (`touch`, copying the working tree) does the same.
    const filepaths = ['README.md', 'package.json', 'src/index.js']
    for (const filepath of filepaths) {
      const object = await fs.read(path.join(dir, filepath))
      const { oid } = await hashBlob({ object })
      await updateIndex({ fs, dir, gitdir, filepath, oid })
    }
    // Count the writes to the index file
    let indexWrites = 0
    const write = fs.write.bind(fs)
    fs.write = (filepath, ...args) => {
      if (filepath === `${gitdirsmfullpath}/index`) indexWrites++
      return write(filepath, ...args)
    }
    // Test
    await checkout({ fs, dir, gitdir, ref: 'test-branch', force: true })
    // One write for the whole analysis, not one per file
    expect(indexWrites).toBe(1)
    // The stat info is up to date now, so there is nothing left to write
    const matrix = await statusMatrix({ fs, dir, gitdir, filepaths })
    expect(matrix).toEqual([
      ['README.md', 1, 1, 1],
      ['package.json', 1, 1, 1],
      ['src/index.js', 1, 1, 1],
    ])
    expect(indexWrites).toBe(1)
  })
})
