/* eslint-env node, browser, jasmine */
import * as path from 'path'

import {
  status,
  add,
  commit,
  init,
  remove,
  setConfig,
  statusMatrix,
} from 'isomorphic-git'

import { makeFixtureAsSubmodule } from './__helpers__/FixtureFSSubmodule.js'

describe('status', () => {
  it('status', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-status')
    // Test
    const a = await status({ fs, dir, gitdir, filepath: 'a.txt' })
    const b = await status({ fs, dir, gitdir, filepath: 'b.txt' })
    const c = await status({ fs, dir, gitdir, filepath: 'c.txt' })
    const d = await status({ fs, dir, gitdir, filepath: 'd.txt' })
    const e = await status({ fs, dir, gitdir, filepath: 'e.txt' })
    expect(a).toEqual('unmodified')
    expect(b).toEqual('*modified')
    expect(c).toEqual('*deleted')
    expect(d).toEqual('*added')
    expect(e).toEqual('absent')

    await add({ fs, dir, gitdir, filepath: 'a.txt' })
    await add({ fs, dir, gitdir, filepath: 'b.txt' })
    await remove({ fs, dir, gitdir, filepath: 'c.txt' })
    await add({ fs, dir, gitdir, filepath: 'd.txt' })
    const a2 = await status({ fs, dir, gitdir, filepath: 'a.txt' })
    const b2 = await status({ fs, dir, gitdir, filepath: 'b.txt' })
    const c2 = await status({ fs, dir, gitdir, filepath: 'c.txt' })
    const d2 = await status({ fs, dir, gitdir, filepath: 'd.txt' })
    expect(a2).toEqual('unmodified')
    expect(b2).toEqual('modified')
    expect(c2).toEqual('deleted')
    expect(d2).toEqual('added')

    // And finally the weirdo cases
    const acontent = await fs.read(path.join(dir, 'a.txt'))
    await fs.write(path.join(dir, 'a.txt'), 'Hi')
    await add({ fs, dir, gitdir, filepath: 'a.txt' })
    await fs.write(path.join(dir, 'a.txt'), acontent)
    const a3 = await status({ fs, dir, gitdir, filepath: 'a.txt' })
    expect(a3).toEqual('*unmodified')

    await remove({ fs, dir, gitdir, filepath: 'a.txt' })
    const a4 = await status({ fs, dir, gitdir, filepath: 'a.txt' })
    expect(a4).toEqual('*undeleted')

    await fs.write(path.join(dir, 'e.txt'), 'Hi')
    await add({ fs, dir, gitdir, filepath: 'e.txt' })
    await fs.rm(path.join(dir, 'e.txt'))
    const e3 = await status({ fs, dir, gitdir, filepath: 'e.txt' })
    expect(e3).toEqual('*absent')

    // Yay .gitignore!
    // NOTE: make_http_index does not include hidden files, so
    // I had to insert test-status/.gitignore and test-status/i/.gitignore
    // manually into the JSON.
    const f = await status({ fs, dir, gitdir, filepath: 'f.txt' })
    const g = await status({ fs, dir, gitdir, filepath: 'g/g.txt' })
    const h = await status({ fs, dir, gitdir, filepath: 'h/h.txt' })
    const i = await status({ fs, dir, gitdir, filepath: 'i/i.txt' })
    expect(f).toEqual('ignored')
    expect(g).toEqual('ignored')
    expect(h).toEqual('ignored')
    expect(i).toEqual('*added')
  })

  it('status in an fresh git repo with no commits', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-empty')
    await fs.write(path.join(dir, 'a.txt'), 'Hi')
    await fs.write(path.join(dir, 'b.txt'), 'Hi')
    await add({ fs, dir, gitdir, filepath: 'b.txt' })
    // Test
    const a = await status({ fs, dir, gitdir, filepath: 'a.txt' })
    expect(a).toEqual('*added')
    const b = await status({ fs, dir, gitdir, filepath: 'b.txt' })
    expect(b).toEqual('added')
  })

  it('does not modify .git/index when refresh is false', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-status')
    // Take an unmodified tracked file and bump its workdir mtime without
    // changing contents, so the racy stat-cache refresh would normally fire.
    const original = await fs.read(path.join(dir, 'a.txt'))
    await fs.write(path.join(dir, 'a.txt'), original)
    // Snapshot the index file
    const indexBefore = await fs.read(path.join(gitdir, 'index'))
    // Read-only status call
    const a = await status({
      fs,
      dir,
      gitdir,
      filepath: 'a.txt',
      refresh: false,
    })
    expect(a).toEqual('unmodified')
    const indexAfter = await fs.read(path.join(gitdir, 'index'))
    expect(indexAfter).toEqual(indexBefore)
  })

  it('tracked file that matches a .gitignore rule', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-add')
    await init({ fs, dir, gitdir })
    // Track the file before it becomes ignored, then change it on disk.
    await add({ fs, dir, gitdir, filepath: 'i.txt' })
    await fs.write(path.join(dir, '.gitignore'), 'i.txt\n')
    await fs.write(path.join(dir, 'i.txt'), 'changed after being ignored')
    // Test
    // .gitignore applies to untracked files only. canonical git reports this
    // file as modified, and `git check-ignore` does not match it at all.
    expect(await status({ fs, dir, gitdir, filepath: 'i.txt' })).toEqual(
      '*added'
    )
  })

  it('honours core.autocrlf when hashing the working copy', async () => {
    // Setup
    const { fs, dir, gitdir } = await makeFixtureAsSubmodule('test-empty')
    await init({ fs, dir, gitdir })
    await setConfig({ fs, dir, gitdir, path: 'core.autocrlf', value: true })
    await fs.write(path.join(dir, 'a.txt'), 'one\ntwo\n')
    await add({ fs, dir, gitdir, filepath: 'a.txt' })
    await commit({
      fs,
      dir,
      gitdir,
      message: 'initial',
      author: { name: 'Test', email: 'test@example.com' },
    })
    // The blob is stored with LF and the working copy carries CRLF. This
    // library never writes CRLF, so on a real machine the working copy got
    // that way from canonical git, an editor, or a syncing tool.
    await fs.write(path.join(dir, 'a.txt'), 'one\r\ntwo\r\n')
    // Test
    // status has to come first. statusMatrix refreshes the index stat cache,
    // and once the cached stats match the CRLF file on disk, status returns the
    // indexed oid without hashing anything, which hides the bug.
    expect(await status({ fs, dir, gitdir, filepath: 'a.txt' })).toEqual(
      'unmodified'
    )
    // GitWalkerFs already reads with the autocrlf option, so statusMatrix
    // agrees the file is untouched either way.
    expect(await statusMatrix({ fs, dir, gitdir })).toEqual([
      ['a.txt', 1, 1, 1],
    ])
  })
})
