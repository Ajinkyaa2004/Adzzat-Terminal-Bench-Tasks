// @ts-check
import { _readTree } from '../commands/readTree.js'
import { NotFoundError } from '../errors/NotFoundError.js'
import { ObjectTypeError } from '../errors/ObjectTypeError.js'
import { GitConfigManager } from '../managers/GitConfigManager.js'
import { GitIgnoreManager } from '../managers/GitIgnoreManager.js'
import { GitIndexManager } from '../managers/GitIndexManager.js'
import { GitRefManager } from '../managers/GitRefManager.js'
import { FileSystem } from '../models/FileSystem.js'
import { GitTree } from '../models/GitTree.js'
import { _readObject } from '../storage/readObject.js'
import { assertParameter } from '../utils/assertParameter.js'
import { compareStats } from '../utils/compareStats.js'
import { discoverGitdir } from '../utils/discoverGitdir.js'
import { hashObject } from '../utils/hashObject.js'
import { join } from '../utils/join.js'

/**
 * Tell whether a file has been changed
 *
 * The possible resolve values are:
 *
 * | status                | description                                                                           |
 * | --------------------- | ------------------------------------------------------------------------------------- |
 * | `"ignored"`           | file ignored by a .gitignore rule                                                     |
 * | `"unmodified"`        | file unchanged from HEAD commit                                                       |
 * | `"*modified"`         | file has modifications, not yet staged                                                |
 * | `"*deleted"`          | file has been removed, but the removal is not yet staged                              |
 * | `"*added"`            | file is untracked, not yet staged                                                     |
 * | `"absent"`            | file not present in HEAD commit, staging area, or working dir                         |
 * | `"modified"`          | file has modifications, staged                                                        |
 * | `"deleted"`           | file has been removed, staged                                                         |
 * | `"added"`             | previously untracked file, staged                                                     |
 * | `"*unmodified"`       | working dir and HEAD commit match, but index differs                                  |
 * | `"*absent"`           | file not present in working dir or HEAD commit, but present in the index              |
 * | `"*undeleted"`        | file was deleted from the index, but is still in the working dir                      |
 * | `"*undeletemodified"` | file was deleted from the index, but is present with modifications in the working dir |
 *
 * @param {object} args
 * @param {FsClient} args.fs - a file system client
 * @param {string} args.dir - The [working tree](dir-vs-gitdir.md) directory path
 * @param {string} [args.gitdir=join(dir, '.git')] - [required] The [git directory](dir-vs-gitdir.md) path
 * @param {string} args.filepath - The path to the file to query
 * @param {object} [args.cache] - a [cache](cache.md) object
 * @param {boolean} [args.refresh = true] - when false, do not refresh the
 *   `.git/index` stat cache when the working-tree file's contents still match
 *   the staged blob. The call becomes read-only with respect to the index, at
 *   the cost of recomputing the SHA1 on subsequent calls for files whose
 *   stat info has drifted.
 *
 * @returns {Promise<'ignored'|'unmodified'|'*modified'|'*deleted'|'*added'|'absent'|'modified'|'deleted'|'added'|'*unmodified'|'*absent'|'*undeleted'|'*undeletemodified'>} Resolves successfully with the file's git status
 *
 * @example
 * let status = await git.status({ fs, dir: '/tutorial', filepath: 'README.md' })
 * console.log(status)
 *
 */
export async function status({
  fs: _fs,
  dir,
  gitdir = join(dir, '.git'),
  filepath,
  cache = {},
  refresh = true,
}) {
  try {
    assertParameter('fs', _fs)
    assertParameter('gitdir', gitdir)
    assertParameter('filepath', filepath)

    const fs = new FileSystem(_fs)
    const updatedGitdir = await discoverGitdir({ fsp: fs, dotgit: gitdir })
    const headTree = await getHeadTree({ fs, cache, gitdir: updatedGitdir })
    const treeOid = await getOidAtPath({
      fs,
      cache,
      gitdir: updatedGitdir,
      tree: headTree,
      path: filepath,
    })
    const indexEntry = await GitIndexManager.acquire(
      { fs, gitdir: updatedGitdir, cache },
      async function (index) {
        for (const entry of index) {
          if (entry.path === filepath) return entry
        }
        return null
      }
    )
    // .gitignore governs untracked files. A file in HEAD or in the index is
    // tracked, so canonical git keeps reporting its real state, and
    // `git check-ignore` does not match it. statusMatrix already does this.
    if (treeOid === null && indexEntry === null) {
      const ignored = await GitIgnoreManager.isIgnored({
        fs,
        gitdir: updatedGitdir,
        dir,
        filepath,
      })
      if (ignored) {
        return 'ignored'
      }
    }
    const stats = await fs.lstat(join(dir, filepath))

    const H = treeOid !== null // head
    const I = indexEntry !== null // index
    const W = stats !== null // working dir

    const getWorkdirOid = async () => {
      if (I && !compareStats(indexEntry, stats)) {
        return indexEntry.oid
      } else {
        // Read through the same core.autocrlf normalisation GitWalkerFs uses,
        // so the working copy hashes to the blob that was stored. Without it a
        // CRLF checkout of an LF blob reads as modified.
        const config = await GitConfigManager.get({ fs, gitdir: updatedGitdir })
        const autocrlf = await config.get('core.autocrlf')
        const object = await fs.read(join(dir, filepath), { autocrlf })
        const workdirOid = await hashObject({
          gitdir: updatedGitdir,
          type: 'blob',
          object,
        })
        // If the oid in the index === working dir oid but stats differed update cache
        if (refresh && I && indexEntry.oid === workdirOid) {
          // and as long as our fs.stats aren't bad.
          // size of -1 happens over a BrowserFS HTTP Backend that doesn't serve Content-Length headers
          // (like the Karma webserver) because BrowserFS HTTP Backend uses HTTP HEAD requests to do fs.stat
          if (stats.size !== -1) {
            // We don't await this so we can return faster for one-off cases.
            GitIndexManager.acquire(
              { fs, gitdir: updatedGitdir, cache },
              async function (index) {
                index.insert({ filepath, stats, oid: workdirOid })
              }
            )
          }
        }
        return workdirOid
      }
    }

    if (!H && !W && !I) return 'absent' // ---
    if (!H && !W && I) return '*absent' // -A-
    if (!H && W && !I) return '*added' // --A
    if (!H && W && I) {
      const workdirOid = await getWorkdirOid()
      // @ts-ignore
      return workdirOid === indexEntry.oid ? 'added' : '*added' // -AA : -AB
    }
    if (H && !W && !I) return 'deleted' // A--
    if (H && !W && I) {
      // @ts-ignore
      return treeOid === indexEntry.oid ? '*deleted' : '*deleted' // AA- : AB-
    }
    if (H && W && !I) {
      const workdirOid = await getWorkdirOid()
      return workdirOid === treeOid ? '*undeleted' : '*undeletemodified' // A-A : A-B
    }
    if (H && W && I) {
      const workdirOid = await getWorkdirOid()
      if (workdirOid === treeOid) {
        // @ts-ignore
        return workdirOid === indexEntry.oid ? 'unmodified' : '*unmodified' // AAA : ABA
      } else {
        // @ts-ignore
        return workdirOid === indexEntry.oid ? 'modified' : '*modified' // ABB : AAB
      }
    }
    /*
    ---
    -A-
    --A
    -AA
    -AB
    A--
    AA-
    AB-
    A-A
    A-B
    AAA
    ABA
    ABB
    AAB
    */
  } catch (err) {
    err.caller = 'git.status'
    throw err
  }
}

async function getOidAtPath({ fs, cache, gitdir: updatedGitdir, tree, path }) {
  if (typeof path === 'string') path = path.split('/')
  const dirname = path.shift()
  for (const entry of tree) {
    if (entry.path === dirname) {
      if (path.length === 0) {
        return entry.oid
      }
      const { type, object } = await _readObject({
        fs,
        cache,
        gitdir: updatedGitdir,
        oid: entry.oid,
      })
      if (type === 'tree') {
        const tree = GitTree.from(object)
        return getOidAtPath({ fs, cache, gitdir: updatedGitdir, tree, path })
      }
      if (type === 'blob') {
        throw new ObjectTypeError(entry.oid, type, 'blob', path.join('/'))
      }
    }
  }
  return null
}

async function getHeadTree({ fs, cache, gitdir: updatedGitdir }) {
  // Get the tree from the HEAD commit.
  let oid
  try {
    oid = await GitRefManager.resolve({
      fs,
      gitdir: updatedGitdir,
      ref: 'HEAD',
    })
  } catch (e) {
    // Handle fresh branches with no commits
    if (e instanceof NotFoundError) {
      return []
    }
  }
  const { tree } = await _readTree({ fs, cache, gitdir: updatedGitdir, oid })
  return tree
}
